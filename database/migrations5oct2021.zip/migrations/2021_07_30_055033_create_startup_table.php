<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStartupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('startup', function (Blueprint $table) {
            $table->id();
            $table->boolean('is_active') -> default(1);
            $table->string('added_by') -> default(1);
            $table->string('updated_by') -> default(1);
            $table->boolean('request') -> default(0);
            $table->longtext('collateral');
            $table->string('company_name');
            $table->longtext('description');
            $table->string('country');
            $table->string('state');
            $table->string('city');
            $table->string('pincode');
            $table->string('zone');
            $table->string('address');
            $table->string('founded_on');
            $table->string('company_type');
            $table->string('industry');
            $table->longtext('type_of_services');
            $table->string('specialities');
            $table->string('company_size');
            $table->string('revenue');
            $table->string('certified');
            $table->string('title');
            $table->string('website');
            $table->string('facebook');
            $table->string('twitter');
            $table->string('linkedin');
            $table->string('instagram');
            $table->string('name');
            $table->string('designation');
            $table->string('email');
            $table->string('phone');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('startup');
    }
}

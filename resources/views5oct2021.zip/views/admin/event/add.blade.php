@extends('admin.layout.index')

@section('title') Admin @endsection

@section('body')
<!-- Content body start -->
<div class="content-body">
    <!-- Container -->
    <div class="container-fluid">
        <!-- Breadcrumbs -->
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Event</h4>
                </div>
            </div>

            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Event</a></li>

                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Add Event</a></li>
                </ol>
            </div>
        </div>
        <!-- Form -->

        <form class="bg-white p-4" name="event" method="POST" action="/admin/event/add" enctype="multipart/form-data">
        @csrf()
            <!-- Image Section -->
            <div class="row">
                <div class="col-12">
                    <h4 class="text-white p-3 bg-primary"><b>Event Images</b></h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Image*</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" name="event_image" />
                            <label class="custom-file-label">Choose file</label>
                            <small class="d-block badge text-secondary text-left">Event image size should be 370px*238px</small>
                        </div>
                        <div class="shadow-sm text-center p-3" data-append="event_image"></div>
                        <small class="text-danger d-block" data-error-event="event_image"></small>
                    </div>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Banner Image*</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" name="event_banner_image" />
                            <label class="custom-file-label">Choose file</label>
                            <small class="d-block badge text-secondary text-left">Event Banner image size should be 1920px*300px</small>
                        </div>
                        <div class="shadow-sm text-center p-3" data-append="event_banner_image"></div>
                        <small class="text-danger d-block" data-error-event="event_banner_image"></small>
                    </div>
                </div>
            </div>
            <!-- Event Details -->
            <div class="row">
                <div class="col-12">
                    <h4 class="mt-4 text-white p-3 bg-primary"><b>Event Basic Information</b></h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Title*</label>
                        <input type="text" class="form-control" name="title" required />
                    </div>
                    <small class="text-danger" data-error-event="title"></small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Category*</label>
                        <select class="form-control" name="category" required>
                            <option value="" disabled selected>Select Category</option>
                            <option value="Online">Online</option>
                            <option value="Offline">Offline</option>
                        </select>
                    </div>
                    <small class="text-danger" data-error-event="category"></small>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Type*</label>
                        <select class="form-control" name="type" required>
                            <option value="" disabled selected>Select Type</option>
                            <option value="paid">Paid</option>
                            <option value="free">Free</option>
                        </select>
                    </div>
                    <small class="text-danger" data-error-event="type"></small>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Price</label>
                        <input type="text" class="form-control" name="price" required />
                    </div>
                    <small class="text-danger" data-error-event="price"></small>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event For *</label>
                        <select class="form-control" name="event_for" required>
                            <option value="" disabled selected>Select Event For</option>
                            <option value="startup">For Startups</option>
                            <option value="pilot">For Pilot Companies</option>
                            <option value="both">For Startups and Pilot Companies</option>
                            <option value="public">For All</option>
                        </select>
                    </div>
                    <small class="text-danger" data-error-event="event_for"></small>
                </div>
            </div>
            <!-- Event Date and Time -->
            <div class="row">
                <div class="col-12">
                    <h4 class="mt-4 text-white p-3 bg-primary"><b>Event Date and Time</b></h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event From*</label>
                        <input type="date" class="form-control" name="event_from" required />
                    </div>
                    <small class="text-danger" data-error-event="event_from"></small>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event To</label>
                        <input type="date" class="form-control" name="event_to" required />
                    </div>
                    <small class="text-danger" data-error-event="event_to"></small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Duration Start*</label>
                        <input type="time" class="form-control" name="event_start" required />
                    </div>
                    <small class="text-danger" data-error-event="event_start"></small>
                </div>
                <div class="col-md-4 mb-2">
                    <div class="form-group">
                        <label class="form-label">Event Duration End*</label>
                        <input type="time" class="form-control" name="event_end" required />
                    </div>
                    <small class="text-danger" data-error-event="event_end"></small>
                </div>
            </div>
            <!-- Event Description -->
            <div class="row">
                <div class="col-12">
                    <h4 class="mt-4 text-white p-3 bg-primary"><b>Event Description</b></h4>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mb-2">
                    <div class="form-group">
                        <label class="form-label">Short Description*</label>
                        <textarea class="form-control" name="short_description"  required rows="12"></textarea>
                    </div>
                    <small class="text-danger" data-error-event="short_description"></small>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mb-2">
                    <div class="form-group">
                        <label class="form-label">Description*</label>
                        <textarea class="form-control" name="description" id="event_description" required rows="12"></textarea>
                    </div>
                    <small class="text-danger" data-error-event="description"></small>
                </div>
            </div>
            <!--|Collateral|-->
            <div class="row">
                <div class="col-12">
                    <h4 class="mt-4 text-white p-3 bg-primary"><b>Collaterals</b></h4>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3">
                    <div class="custom-file">
                        <input type="file" class="form-control" data-sh="collateral" multiple>
                    </div>
                    <div data-sh="collateral-data"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary mt-4">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Content body end -->
@endsection
@section('script')
<link href="https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/suneditor@latest/dist/suneditor.min.js" defer="true"></script>
<script src="https://cdn.jsdelivr.net/npm/suneditor@latest/src/lang/en.js" defer="true"></script>
<script src="{{ asset('/assets/admin/js/textEditor.js') }}"></script>
<script>
    const renderImage = event => {
        if(event.target.files.length > 0)
        {
            fileUpload(event.target.files[0]).then(response => {
                document.querySelector(`div[data-append='${event.target.name}']`).innerHTML
                = `<img src="${response}" class="img-fluid" style="max-height: 300px">`;
            })
        }
    }
    document.forms.event.event_image.addEventListener("change", renderImage)
    document.forms.event.event_banner_image.addEventListener("change", renderImage)

    let editor;
    window.onload = () => {
        editor = initializeEditor('event_description');
        editor.onChange = function (contents, isChanged) {
            document.forms.event.description.value = contents;
        }
    }
    
    /*
    |Multiple Image Upload
    ---------------------- */
    const multipleImage = (e, f) => {
        const files = e.files;
        let b, element, input, temp;
        for(let i = 0; i < files.length; i++) {
                b = new ClipboardEvent("").clipboardData || new DataTransfer();
                b.items.add(files[i]);
                element = document.createElement('div');
                element.classList.add("d-flex")
                element.setAttribute("data-sh-collateral", `${files[i].name}`);
                    input = document.createElement('input');
                    input.setAttribute("name", f+'[]');
                    input.setAttribute("type", "file");
                    input.files = b.files;
                    input.classList.add("d-none");
                element.innerHTML = `<div>${files[i].name}</div>
                                    <div onclick="this.parentElement.remove();"><i class="fa fa-trash ml-2 text-danger"></div>`;
                element.appendChild(input);
                document.querySelector(`div[data-sh="collateral-data"]`).appendChild(element);
        }
        this.value = '';
    }
    document.querySelector(`input[data-sh="collateral"]`).addEventListener('change', function() { multipleImage(this, 'collateral') });

    const submitForm = event => {
        event.preventDefault();
        const fd = new FormData(event.target);
        commonAjax({
            page: 'admin/event/add',
            params: fd
        }).then(response => {
            snackbar(response?.message || "Something went wrong");
            if(response?.success)window.location.href="./";
            let errors = response.errors || {};
            for(let [key, name] of Object.entries(errors)) {
                document.querySelector(`small[data-error-event='${key}']`).innerHTML = name;
            }
        })
        .catch(err => snackbar("Something went wrong"))
    }
    document.forms.event.addEventListener("submit", submitForm)
</script>
@endsection
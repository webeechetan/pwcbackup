<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
</head>

<body style="margin: 0;  padding-left: 10px; padding-right: 10px;">
    <table cellspacing="0" cellpadding="0" width="100%">
		<tr>
			<td style="width: 50%;"><img src="https://www.acma.in/img/acma-logo.png"></td>
			<td style="width: 50%;">
                <p style="text-align: right;">6th floor, The Capital Court<br>
                Olof Palme Marg, Manirka<br>
                New Delhi 110 067, India<br>
                Tel: +91-11-26160315 Fax: +91-11-26160317<br>
                <a href="mailto:acma@acma.in">acma@acma.in</a>, <a href="https://www.acma.in/" target="_blank">www.acma.in</a></p>
			</td>
		</tr>
    </table>
    <table border="0" width="100%" style="padding:30px 20px 50px;">
	<tr>
        <td align="left" style="width: 100%; font-size:15px; color:#676777; font-family: Arial, Helvetica, sans-serif; line-height: 20px;">{!! $body !!} <br/></td>
    </tr>                    
</table>
</body>

</html>